#include <stdio.h>
#include "dfa.h"
#include "IntHashSet.h"
#include "nfa.h"
#include "stdbool.h"
#include <string.h>

typedef struct string string;
void DFA_repl(DFA dfa) {
    //creating a dfa called quit that only accepts the string ''
    //if quit is run, this DDFA will execute returning true and then exit the REPL function
    DFA test = new_DFA(4); //states of 4 (5?) total only, limit
    DFA_set_transition(test, 0, 'e', 1);
    DFA_set_transition(test, 1, 'x', 2);
    DFA_set_transition(test, 2, 'i', 3);
    DFA_set_transition(test, 3, 't', 4);
    DFA_set_accepting(test, 4, true);

    while (true) {
        printf("enter here (enter\"exit\" to exit)\n");
        char str[50];
        fgets(str, 50, stdin);
        if ((strlen(str) > 0) && (str[strlen(str) - 1] == '\n')) {
            str[strlen(str) - 1] = '\0';
        }
        bool e = DFA_execute(dfa, str);
        if (e) {
            break;
        } else {
            bool result = DFA_execute(dfa, str);
            char *message = "Result for the input";
            if (result) {
                printf("%s \"%s\" : true\n", message, str);
            } else {
                printf("%s \"%s\" : false\n", message, str);

            }

        }
        printf("Question Exited.\n");

    }

    int main(int arguments, char *argv[]) {

        // DFA_print(dfa1);
        IntHashSet test;
        test = "CSC";
        if (DFA_for_contains_CSC(test) == true) {
            std:
            cout << "The string " << test << " is accepted";
        } else {
            std:
            cout << "the string" << test << "is not accepted";
        }
        IntHashSet test2;
        test2 = "ending"
        if (DFA_for_contains_end(test2) == true) {
            cout << "The string" << test << "is accepted";

            else

        }
        //DFA_for_contains_CSC();
        //DFA_for_contains_end();
        //DFA_for_starts_with_vowel();
        return 0;
    }

}
