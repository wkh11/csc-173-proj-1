//
// Created by Sana Tahir on 9/16/23.
//

#include "nfa.h"
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "IntHashSet.h"

// Define the NFA struct
struct NFA {
    //number of states
    int nStates;
    //
    NFA_State states;
    //current state/ start state
    IntHashSet currentTransitions;
};

struct NFA_State {
    //transition table
    IntHashSet inputAlphabet[128];
    //final state
    bool isAcceptingState;
};

// Implementation of new_NFA function
NFA new_NFA(int nStates) {
    //allows us to free space for DFA
    NFA this = (NFA)malloc(sizeof(struct NFA));

    if (this == NULL) {
        printf("Memory Allocation failed.\n");
        return NULL; // Out of memory...
    }

    this->nStates = nStates;
    //our states will be reprsented with hashsets
    IntHashSet startState = new_IntHashSet(10);
    //initializes 0 as the start state
    IntHashSet_insert(startState, 0);
    //currently at value 0. Set tells you where you can go from state 0
    this->currentTransitions = startState;
    //allows us to free space for NFA_State
    this->states = (NFA_State)malloc(sizeof(struct NFA_State));
    //ex: for pattern "CSC", we need initial state(0) then (1) -> (2) -> (3). 3 is the final state

    //insert new set for each value in ascii alphabet
    for (int i = 0; i < nStates; i++) {
        //base case: initialize all current states to false
        this->states[i].isAcceptingState = false;
    }

    //psuedo code
    // at each state, n, set each of the values to false
    for (int i = 0; i < nStates; i++) {
        //48 is where the numbers start
        for (int j = 48; j < 128; j++) {
            //if val in transition table is set to -1, that means value is rejected
            this->states[i].inputAlphabet[j] = new_IntHashSet(10);
        }
    }
    //if there are 7 states, and state 7 is reached, which is the length of the states, then we return true
    return this;
}

// Function to free NFA memory
void NFA_free(NFA nfa) {
    //first have to free up each of the hashsets in each row associated with each ascii value
    for (int i = 0; i < nfa->nStates; i++) {
        for (int j = 0; j < 128; j++) {
            IntHashSet_free(nfa->states[i].inputAlphabet[j]);
        }
    }
    //free up the state
    IntHashSet_free(nfa->currentTransitions);

    //now free up nfa state and nfa
    free(nfa->states);
    free(nfa);
}

// Function to get the number of states in the NFA
int NFA_get_size(NFA nfa) {
    return nfa->nStates;
}

/**
 * Return the set of next states specified by the given NFA's transition
 * function from the given state on input symbol sym.
 */
 IntHashSet NFA_get_transitions(NFA nfa, int state, char sym) {
     //return the set at that state and that character
     return nfa->states[state].inputAlphabet[sym];
}

// Function to add a transition
void NFA_add_transition(NFA nfa, int currState, char sym, int destinationState) {
     //inserts value into the hashset associated with that letter
    IntHashSet_insert(nfa->states[currState].inputAlphabet[sym], destinationState);
}

void NFA_add_transition_str(NFA nfa, int src, char *str, int destinationState) {
     //loop until string is empty
     for (int i = src; i < str[i] != '\0'; i++) {
         //number of states is equal to the length of the pattern
         //depending on the letter we read, we will go inside state(aka row) then the hashset associated with that letter and assign it the destination state
         IntHashSet_insert(nfa->states[i].inputAlphabet[str[i]], destinationState);
     }
}

void NFA_add_transition_all(NFA nfa, int src, int dst) {
    for (int i = 0; i < 128; i++) {
        //assign every value in alphabet the same value in that row
        IntHashSet_insert(nfa->states[src].inputAlphabet[i], dst);
    }
}

// Function to set accepting or non-accepting states
void NFA_set_accepting(NFA nfa, int state, bool value) {
     //at state(ex: 7), we assign it the boolean "value"
    nfa->states[state].isAcceptingState = value;
}

// Function to get accepting or non-accepting states
bool NFA_get_accepting(NFA nfa, int state) {
    return nfa->states[state].isAcceptingState;
}

// Function to execute an NFA on a given input string
bool NFA_execute(NFA nfa, char* input) {
    //call function recursively
}

bool NFA_Recursive_Tree(NFA nfa, IntHashSet startStates,char* input) {
    IntHashSetIterator iterator = IntHashSet_iterator(startStates);

    //while the hashset
    while (IntHashSetIterator_hasNext(iterator)) {
        //check if current value in hashset is null
    }

 }

// Function to run an NFA on a given input string
bool NFA_run(NFA nfa, char* input) {
    if (nfa == NULL) {
        return false;
    }
}


NFA* NFA_for_ends_with_at() {
    NFA* nfa = new_NFA(2);
    if (nfa == NULL) {
        return NULL;
    }
    return nfa;
}

NFA* NFA_for_strings_containing_got() {
    NFA* nfa = new_NFA(2);
    if (nfa == NULL) {
        return NULL;
    }
    return nfa;
}

NFA* NFA_for_specific_letter_counts() {
    NFA* nfa = new_NFA(5); // Adjust the number of states as needed
    if (nfa == NULL) {
        return NULL;
    }
    return nfa;
}
