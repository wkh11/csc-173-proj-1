//
// Created by Sana Tahir on 9/12/23.
//
//in dfa.c we define our data structure

#include "dfa.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct DFA {
    //include the five tuple here
    int nStates;
    //126 to represent the ascii alphabet, which encompasses every possible keyboard letter
    int startOrCurrState;
    DFA_State states;
};
//relationship: DFA defines # of states, startingState. DFA_State is the transition table
struct DFA_State {
    //state "s" and symbol "x" can be represented as a table
    //one entry for each combo of s and x
    //transitionTable[number of states][all the ascii values go here. if not val we are looking for, set as -1]
    //each state has following information: where it can go next.
    //if it is the accepting state
    bool isAcceptingState;
    int inputAlphabet[128];
};

//now create new instance of a DFA
DFA new_DFA(int nStates) {
    //allows us to free space for DFA
    DFA this = (DFA)malloc(sizeof(struct DFA));

    if (this == NULL) {
        printf("Memory Allocation failed.\n");
        return NULL; // Out of memory...
    }

    this->nStates = nStates;
    this->startOrCurrState = 0;
    //allows us to free space for DFA_State
    this->states = (DFA_State)malloc(sizeof(struct DFA_State));
//    this->states->acceptingState = 10;
    //ex: for pattern "CSC", we need initial state(0) then (1) -> (2) -> (3). 3 is the final state
    for (int i = 0; i < nStates; i++) {
        //base case: initialize all current states to false
        this->states[i].isAcceptingState = false;
    }

    //psuedo code
    // at each state, n, set each of the values to false
    for (int i = 0; i < nStates; i++) {
        for (int j = 48; j < 128; j++) {
            //if val in transition table is set to -1, that means value is rejected
            this->states[i].inputAlphabet[j] = -1;
        }
    }
    //if there are 7 states, and state 7 is reached, which is the length of the states, then we return true
    return this;
}

void DFA_print(DFA dfa) {
    for (int i = 0; i < dfa->nStates; i++) {
        //this is range of the alphabet for lower and upper case
        for (int j = 48; j < 128; j++) {
            printf("%d, ", dfa->states[i].inputAlphabet[j]);
        }
        printf("\n");
    }
}

//Frees up or dynamically allocated memory
void DFA_free(DFA dfa) {
    //check if pointer == null before dereferencing -> it can prevent crashes
    free(dfa->states);
    free(dfa);
}

//returns size of DFA
int DFA_get_size(DFA dfa) {
    return dfa->nStates;
}

/**
 * Return the state specified by the given DFA's transition function from
 * state src on input symbol sym.
 */
int DFA_get_transition(DFA dfa, int currState, char input) {
    //currState represents what state you are currently on
    //input represents the current input character. we check if this input character either stays at curr state. or goes to next state.
    //the next state for valid input is defined in DFA_set_transition
    //so this function returns what state you go to next. either stay or go to another state
    return dfa->states[currState].inputAlphabet[input];

}

/**
 * For the given DFA, set the transition from state src on input symbol
 * sym to be the state dst.
 * state "destination state"?
 */
void DFA_set_transition(DFA dfa, int sourceState, char input, int destinationState) {
    //void function because we are simply accessing the 2d array and assigning it the destination State
    //ex: for pattern csc
    //at state[1].theInputAlphabetWillBe[this letter char].
/**
    since ascii values are assigned a numerical value, we can place "char input" into our input alphabet array,which
    is of size 126, representing ascii alphabet. when we need to retrieve it, we can the numerical value
    can help us figure out which letter it represents
**/
    dfa->states[sourceState].inputAlphabet[input] = destinationState;
}

/**
 * Set the transitions of the given DFA for each symbol in the given str.
 * This is a nice shortcut when you have multiple labels on an edge between
 * two states.
 */
void DFA_set_transition_str(DFA dfa, int src, char *str, int dst) {
    int currentState = src;
    int destination = 1;
    for (int i = 0; str[i] != '\0'; i++) {
        char input = str[i];
        //edit made by wei: we do "dst + 1" because for ex: at state 0, if the pattern "csc" if input = c, it should transition to dst+1
        //which means state is accepted, now go to next state
        DFA_set_transition(dfa, currentState, input, destination);
        currentState++;  // Updates the current state for the next iteration
        destination++;
    }

//    DFA_set_transition(dfa, 0, 'C', 1);
//    DFA_set_transition(dfa, 1, 'S', 2);
//    DFA_set_transition(dfa, 2, 'C', 3);
}

/**
 * Set the transitions of the given DFA for all input symbols.
 * Another shortcut method.
 */
void DFA_set_transition_all(DFA dfa, int src, int dst) {
    // Iterates through all possible input symbols (all the ASCII values 0 to 127)
    //I changed input to 65 bcuz that is where the ascii alphabet starts
    for (int input = 65; input < 128; input++) {
        DFA_set_transition(dfa, src, (char)input, dst);
    }
    //always run this method first before set_transition_str -> this assigns every value in the row the same val.
    //so on row 0, every value is assigned 0
}

/**
 * Set whether the given DFA's state is accepting or not.
 */
void DFA_set_accepting(DFA dfa, int acceptingState, bool value) {
    //here, we must go into the final state and set it equal to the final state number so that if it is reached, we return true
    //value = final state number
    dfa->states[acceptingState].isAcceptingState = value;
}

/**
 * Return true if the given DFA's state is an accepting state.
 */
bool DFA_get_accepting(DFA dfa, int state) {
    //given the dfa, and the current state, we check if that state was assigned to be the accepting_state
//    printf("%d ", dfa->states[state].isAcceptingState);
    return dfa->states[state].isAcceptingState;
}

bool DFA_execute(DFA dfa, const char *input) {
    //input is the user input string that we are testing

    //honestly I think current state can be set equal to 0
    int currentState = dfa->startOrCurrState;
    //loop through the string
    for (int i = 0; input[i] != '\0'; i++) {
        char currentSymbol = input[i];
        // Get the next state based on the current state and input symbol
        int nextState = DFA_get_transition(dfa, currentState, currentSymbol);
        // If the transition leads to an invalid state, reject the input
        //or if the transition leads to an accepting state, return and exit
        //printf("this is the current status of string: %d \n", DFA_get_accepting(dfa, i));


        if (DFA_get_accepting(dfa, nextState) == true) {
            return true;
        }
        else if (nextState == -1) {
            return false;
        }

        currentState = nextState; // Move to the next state
    }
    // Check if the final state is an accepting state
    return DFA_get_accepting(dfa, currentState);
}

int DFA_for_contains_CSC() {
    DFA dfa = new_DFA(4); // 4 states for this DFA
    //loop checks true/false values for each state
//    for (int i = 0; i < 4; i++) {
//        //base case: initialize all current states to false
//        //debug: all values return 0, which means it is false
//
//        printf("%d ", DFA_get_accepting(dfa1, i));
//    }

    //need to do this because set_transition_all is randomly assigning dfa1 at state 2 to true
    DFA_set_accepting(dfa, 2, false);
    DFA_set_transition_str(dfa, 0, "CSC", 0);
    DFA_set_accepting(dfa, 3, true);

    DFA_execute(dfa, "CSC") ? printf("TRUE") : printf("FALSE");

}

void DFA_for_contains_end() {
    DFA dfa = new_DFA(4); // 5 states for this DFA: null -> e -> n -> d
    // Define transitions for the DFA
    DFA_set_transition_all(dfa, 0, 0);
    DFA_set_transition_all(dfa, 1, 0);
    DFA_set_transition_all(dfa, 2, 0);

    DFA_set_transition_str(dfa, 0, "end", 0);
    //DFA_print(dfa);
    DFA_set_accepting(dfa, 3, true);
    DFA_execute(dfa, "end") ? printf("TRUE") : printf("FALSE");

//    for (int i = 0; i < 4; i++) {
//        //base case: initialize all current states to false
//        //debug: all values return 0, which means it is false
//
//        printf("%d ", DFA_get_accepting(dfa, i));
//    }
}

void DFA_for_starts_with_vowel() {
    DFA dfa = new_DFA(2); // 2 states for this DFA
    // Define transitions for the DFA


    //this is my set transition string
    DFA_set_transition(dfa, 0, 'a', 1);
    DFA_set_transition(dfa, 0, 'e', 1);
    DFA_set_transition(dfa, 0, 'i', 1);
    DFA_set_transition(dfa, 0, 'o', 1);
    DFA_set_transition(dfa, 0, 'u', 1);

    DFA_print(dfa);

    DFA_set_accepting(dfa, 1, true);

    //I need it to stop running the string and for loop
    DFA_execute(dfa, "ptplkjahygf") ? printf("TRUE") : printf("FALSE");
}

DFA DFA_for_even_count() {
    DFA dfa = new_DFA(4); // 4 states for this DFA
    // Define transitions for the DFA
    DFA_set_transition(dfa, 0, '0', 1);
    DFA_set_transition(dfa, 0, '1', 2);
    DFA_set_transition(dfa, 1, '0', 0);
    DFA_set_transition(dfa, 1, '1', 3);
    DFA_set_transition(dfa, 2, '0', 3);
    DFA_set_transition(dfa, 2, '1', 0);
    DFA_set_transition(dfa, 3, '0', 2);
    DFA_set_transition(dfa, 3, '1', 1);
    // Set the accepting state
    DFA_set_accepting(dfa, 0, true);
    return dfa;
}

//read-eval-print-loop
void DFA_repl(DFA dfa) {
    char input[256]; // Assuming a maximum input length of 255 characters
    while (1) {
        printf("Enter an input string (or 'exit' to quit): ");
        fgets(input, sizeof(input), stdin);
        input[strlen(input) - 1] = '\0'; // Remove the newline character
        if (strcmp(input, "exit") == 0) {
            break; // Exit the REPL
        }
        bool result = DFA_execute(dfa, input);
        printf("Result: %s\n", result ? "Accept" : "Reject");
    }
}




